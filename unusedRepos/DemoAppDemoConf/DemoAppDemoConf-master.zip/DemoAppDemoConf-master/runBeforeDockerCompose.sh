#!/bin/bash
if [ -z $1 ];then
 echo "Need to pass directory of the workspace"
 exit 1
fi
interface=`route | grep -w "default" | awk '{print $8}'`
ip=`ifconfig | grep -A1 ${interface} | awk -F":" '/inet addr/ {print $2}' | awk '{print $1}'`
command1="sed -i 's/HOSTIP/$ip/g' docker-compose.yml"
eval $command1
newstring=""
IFS='/' read -r -a array <<< "$1"
for element in "${array[@]}"
do
    echo "$element"
    newstring="$newstring$element\/"
    echo "newstring=$newstring"
done
command2="sed -i 's/WORKSPACE/$newstring/g' docker-compose.yml"
echo "commnad2=$command2"
eval $command2
docker login -u=advantageonlineshoppingapp -p=W3lcome1
docker-compose up -d
