import configparser
import os
from angular_flask import app
config = configparser.ConfigParser()
DEBUG = True
SECRET_KEY = 'temporary_secret_key'  # make sure to change this
config.read(os.path.join(os.path.abspath(os.path.dirname(__file__)), 'conf', 'properties.ini'))
POSTGRES_URL = config['DB']["POSTGRES_URL"]
POSTGRES_USER = config['DB']["POSTGRES_USER"]
POSTGRES_PW = config['DB']["POSTGRES_PW"]
POSTGRES_DB = config['DB']["POSTGRES_DB"]
DB_URL = 'postgresql+psycopg2://{user}:{pw}@{url}/{db}'.format(user=POSTGRES_USER,pw=POSTGRES_PW,url=POSTGRES_URL,db=POSTGRES_DB)


SQLALCHEMY_DATABASE_URI = DB_URL
app.config['SQLALCHEMY_DATABASE_URI'] = DB_URL
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False # silence the deprecation warning